package net.mcreator.dedsafio3.init;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.mcreator.dedsafio3.Dedsafio3Mod;
import net.mcreator.dedsafio3.world.inventory.TikiGuiMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.inventory.MenuType;

public class Dedsafio3ModMenus {
    public static final MenuType<TikiGuiMenu> TIKI_GUI = Registry.register(BuiltInRegistries.MENU,
            Dedsafio3Mod.id("tiki_gui"),
            new ExtendedScreenHandlerType<TikiGuiMenu, BlockPos>(
                    (syncId, inventory, pos) -> new TikiGuiMenu(syncId, inventory, pos), BlockPos.STREAM_CODEC));

    public static void register() {
    }
}
