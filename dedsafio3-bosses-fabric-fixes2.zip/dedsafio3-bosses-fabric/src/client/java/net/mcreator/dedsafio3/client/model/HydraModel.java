package net.mcreator.dedsafio3.client.model;

import net.mcreator.dedsafio3.entity.HydraEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class HydraModel extends GeoModel<HydraEntity> {
    @Override
    public ResourceLocation getAnimationResource(HydraEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("dedsafio3", "animations/hydra.animation.json");
    }

    @Override
    public ResourceLocation getModelResource(HydraEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("dedsafio3", "geo/hydra.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(HydraEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("dedsafio3", "textures/entities/" + entity.getTexture() + ".png");
    }
}
