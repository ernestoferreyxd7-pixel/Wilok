package net.mcreator.dedsafio3.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.mcreator.dedsafio3.client.model.HydraModel;
import net.mcreator.dedsafio3.entity.HydraEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class HydraRenderer extends GeoEntityRenderer<HydraEntity> {
    public HydraRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new HydraModel());
        this.shadowRadius = 2.0f;
    }

    @Override
    public RenderType getRenderType(HydraEntity animatable, ResourceLocation texture, MultiBufferSource bufferSource, float partialTick) {
        return RenderType.entityTranslucent(getTextureLocation(animatable));
    }

    @Override
    public void preRender(PoseStack poseStack, HydraEntity animatable, BakedGeoModel model, MultiBufferSource bufferSource, VertexConsumer buffer,
                          boolean isReRender, float partialTick, int packedLight, int packedOverlay, int colour) {
        this.scaleHeight = 1.5f;
        this.scaleWidth = 1.5f;
        super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, colour);
    }
}
